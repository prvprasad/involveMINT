package org.involvemint.data.dao;

import java.sql.Blob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.involvemint.data.manager.ConnectionManager;
import org.involvemint.data.model.Organization;

public class OrganizationDAO {

	public static byte[] getLogoImageBytes(Integer orgPk) {
		Connection conn = ConnectionManager.getConnection();
		try {
			PreparedStatement stmt1;

			stmt1 = conn.prepareStatement("select IMAGE from involvemint.organization where ORG_PK = ?");

			ResultSet rs = stmt1.executeQuery();
			byte[] imageBytes;
			if (rs.next()) {
				imageBytes = rs.getBytes("IMAGE");
				return imageBytes;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			ConnectionManager.closeConnection(conn);
		}
		return null;
	}

	public static Organization addOrganization(Organization org) {
		Connection conn = ConnectionManager.getConnection();

		PreparedStatement stmt1;
		PreparedStatement stmt2;
		PreparedStatement stmt3;
		try {

			stmt2 = conn.prepareStatement(
					"INSERT INTO involvemint.address(ADDRESS1, ADDRESS2, CITY, STATE, ZIP, COUNTRY, LATITUDE, LONGITUDE) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
			stmt2.setString(1, org.getAddress().getAddress1());
			stmt2.setString(2, org.getAddress().getAddress2());
			stmt2.setString(3, org.getAddress().getCity());
			stmt2.setString(4, org.getAddress().getState());
			stmt2.setString(5, org.getAddress().getZip());
			stmt2.setString(6, org.getAddress().getCountry());
			stmt2.setDouble(7, org.getAddress().getLongitude());
			stmt2.setDouble(8, org.getAddress().getLatitude());

			stmt2.executeUpdate();

			stmt1 = conn.prepareStatement(
					"INSERT INTO involvemint.organization(ORG_TYPE, ORG_NAME, ORG_DESC, PHONE, EMAIL_ID, WEBSITE_URL, IMAGE_URL, ADDRESS_PK) VALUES (?, ?, ?, ?, ?, ?, ?, LAST_INSERT_ID())");

			stmt1.setString(1, org.getOrgType());
			stmt1.setString(2, org.getOrgName());
			stmt1.setString(3, org.getOrgDesc());
			stmt1.setString(4, org.getPhone());
			stmt1.setString(5, org.getEmailId());
			stmt1.setString(6, org.getWebsiteURL());
			stmt1.setString(7, org.getImageURL());
			stmt1.executeUpdate();

			stmt3 = conn
					.prepareStatement("UPDATE involvemint.organization SET IMAGE = ? where ORG_PK = LAST_INSERT_ID()");
			Blob blob = conn.createBlob();

			blob.setBytes(1, org.getImage());

			stmt3.setBlob(1, blob);
			stmt3.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			ConnectionManager.closeConnection(conn);
		}
		return org;
	}
}
