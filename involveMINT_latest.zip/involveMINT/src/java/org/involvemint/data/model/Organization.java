package org.involvemint.data.model;

import java.util.Arrays;

public class Organization {
	private Integer orgPk;
	private String orgType;
	private String orgName;
	private String orgDesc;
	private String phone;
	private String emailId;
	private String websiteURL;
	private byte[] image;
	private String fileName;
	private String imageURL;
	private Integer addressPk;

	private Address address;

	public Integer getOrgPk() {
		return orgPk;
	}

	public void setOrgPk(Integer orgPk) {
		this.orgPk = orgPk;
	}

	public String getOrgType() {
		return orgType;
	}

	public void setOrgType(String orgType) {
		this.orgType = orgType;
	}

	public String getOrgName() {
		return orgName;
	}

	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}

	public String getOrgDesc() {
		return orgDesc;
	}

	public void setOrgDesc(String orgDesc) {
		this.orgDesc = orgDesc;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getWebsiteURL() {
		return websiteURL;
	}

	public void setWebsiteURL(String websiteURL) {
		this.websiteURL = websiteURL;
	}

	public byte[] getImage() {
		return image;
	}

	public void setImage(byte[] image) {
		this.image = image;
	}

	public String getImageURL() {
		return imageURL;
	}

	public void setImageURL(String imageURL) {
		this.imageURL = imageURL;
	}

	public Integer getAddressPk() {
		return addressPk;
	}

	public void setAddressPk(Integer addressPk) {
		this.addressPk = addressPk;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	@Override
	public String toString() {
		return "Organization [orgPk=" + orgPk + ", orgType=" + orgType + ", orgName=" + orgName + ", orgDesc=" + orgDesc
				+ ", phone=" + phone + ", emailId=" + emailId + ", websiteURL=" + websiteURL + ", image="
				+ Arrays.toString(image) + ", fileName=" + fileName + ", imageURL=" + imageURL + ", addressPk="
				+ addressPk + ", address=" + address + "]";
	}
	
	
}
