package org.involvemint.data.model;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

public class ProjectType {
	private Integer projTypePk;
	private String projTypeName;
	private String activeInd;
	private double weightage;

	public ProjectType() {
		// TODO Auto-generated constructor stub
	}
	
	public ProjectType(Integer pk, String name, String activeInd, double weightage) {
		this.projTypePk = pk;
		this.projTypeName = name;
		this.activeInd = activeInd;
		this.weightage = weightage;
	}

	public Integer getProjTypePk() {
		return projTypePk;
	}

	public void setProjTypePk(Integer projTypePk) {
		this.projTypePk = projTypePk;
	}

	public String getProjTypeName() {
		return projTypeName;
	}

	public void setProjTypeName(String projTypeName) {
		this.projTypeName = projTypeName;
	}

	public String getActiveInd() {
		return activeInd;
	}

	public void setActiveInd(String activeInd) {
		this.activeInd = activeInd;
	}

	public double getWeightage() {
		return weightage;
	}

	public void setWeightage(double weightage) {
		this.weightage = weightage;
	}

	@Override
	public String toString() {
		return "ProjectType [projTypePk=" + projTypePk + ", projTypeName=" + projTypeName + ", activeInd=" + activeInd
				+ ", weightage=" + weightage + "]";
	}

}
