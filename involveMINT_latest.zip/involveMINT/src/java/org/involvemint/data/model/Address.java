package org.involvemint.data.model;

public class Address {
	private Integer addressPk;
	private String addressType;
	private String address1;
	private String address2;
	private String city;
	private String state;
	private String zip;
	private String country;
	private String formatted_address;
	private double latitude;
	private double longitude;

	public Integer getAddressPk() {
		return addressPk;
	}

	public void setAddressPk(Integer addressPk) {
		this.addressPk = addressPk;
	}

	public String getAddressType() {
		return addressType;
	}

	public void setAddressType(String addressType) {
		this.addressType = addressType;
	}

	public String getAddress1() {
		return address1;
	}

	public void setAddress1(String address1) {
		this.address1 = address1;
	}

	public String getAddress2() {
		return address2;
	}

	public void setAddress2(String address2) {
		this.address2 = address2;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getZip() {
		return zip;
	}

	public void setZip(String zip) {
		this.zip = zip;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public double getLatitude() {
		return latitude;
	}

	public void setLatitude(double latitude) {
		this.latitude = latitude;
	}

	public double getLongitude() {
		return longitude;
	}

	public void setLongitude(double longitude) {
		this.longitude = longitude;
	}

	public String getFormatted_address() {
		return formatted_address;
	}

	public void setFormatted_address(String formatted_address) {
		this.formatted_address = formatted_address;
	}

	@Override
	public String toString() {
		return "Address [addressPk=" + addressPk + ", addressType=" + addressType + ", address1=" + address1
				+ ", address2=" + address2 + ", city=" + city + ", state=" + state + ", zip=" + zip + ", country="
				+ country + ", formatted_address=" + formatted_address + ", latitude=" + latitude + ", longitude="
				+ longitude + "]";
	}
}
