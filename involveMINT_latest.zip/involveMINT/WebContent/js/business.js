(function() {

	var app = angular.module("orgApp", []);

	remoteHost = 'https://maps.googleapis.com/maps/api/geocode/json?address=';

	app.directive('fileModel', [ '$parse', function($parse, $scope) {
		return {
			restrict : 'A',
			link : function(scope, element, attrs) {
				var model = $parse(attrs.fileModel);
				var modelSetter = model.assign;

				element.bind('change', function() {
					scope.$apply(function() {
						modelSetter(scope, element[0].files[0]);

						scope.uploadFile()
					});
				});
			}
		};
	}]);

	app.service('fileUpload', [ '$http', function($http) {
		this.uploadFileToUrl = function(file, uploadUrl, $scope) {
			var fd = new FormData();
			fd.append('file', file);

			$http.post(uploadUrl, fd, {
				transformRequest : angular.identity,
				headers : {
					'Content-Type' : undefined
				}
			})

			.success(function(data, status) {
				$scope.org.fileName = data.fileName;
				$scope.org.imageURL = data.fileName;
			})

			.error(function() {
			});
		}
	} ]);

	app
			.controller(
					"businessCtrl",
					[
							'$scope',
							'$http',
							'$location',
							'$window',
							'fileUpload',
							function($scope, $http, $location, $window,
									fileUpload) {
								var app = this;

								$scope.page = 'first';
								$scope.org = {
									orgPk : '',
									orgType : 'B',
									orgName : '',
									orgDesc : '',
									phone : '',
									emailId : '',
									websiteURL : '',
									image : '',
									imageURL : '',
									fileName : '',
									address : {
										addressPk : '',
										address1 : '',
										address2 : '',
										city : '',
										state : '',
										zip : '',
										country : '',
										formatted_address : '',
										latitude : '',
										longitude : ''
									}
								};

								$scope.operation = 'create'

								$scope.first_tab = function() {
									$scope.page = 'first';
								}

								$scope.next_address = function() {
									$scope.page = 'address';
								}

								$scope.next_contact = function() {
									angular
											.forEach(
													$scope.locations,
													function(element) {
														if (element.formatted_address == $scope.org.address.formatted_address) {
															$scope.org.address.latitude = element.geometry.location.lat;
															$scope.org.address.longitude = element.geometry.location.lng;

															angular
																	.forEach(
																			element.address_components,
																			function(
																					addresscomponent) {
																				if (addresscomponent.types == 'street_number') {
																					$scope.org.address.address1 = addresscomponent.short_name;
																				}
																				if (addresscomponent.types == 'route') {
																					$scope.org.address.address1 = $scope.org.address.address1
																							+ ' '
																							+ addresscomponent.short_name;
																				}
																				if (addresscomponent.types[0] == 'locality') {
																					$scope.org.address.city = addresscomponent.short_name;
																				}
																				if (addresscomponent.types[0] == 'administrative_area_level_1') {
																					$scope.org.address.state = addresscomponent.short_name;
																				}
																				if (addresscomponent.types == 'postal_code') {
																					$scope.org.address.zip = addresscomponent.short_name;
																				}
																				if (addresscomponent.types[0] == 'country') {
																					$scope.org.address.country = addresscomponent.short_name;
																				}

																				// if
																				// (element.formatted_address
																				// ==
																				// $scope.org.address.formatted_address)
																				// {
																				// $scope.org.address.latitude
																				// =
																				// element.geometry.location.lat;
																				// $scope.org.address.longitude
																				// =
																				// element.geometry.location.lng;
																				//																			
																				//																			
																				// }
																			});

														}
													});

									$scope.page = 'contact';
								}

								$scope.next_address_pick = function() {

									var addr = $scope.org.address.address1
											+ ',' + $scope.org.address.city
											+ ',' + $scope.org.address.state
											+ ' ' + $scope.org.address.zip;
									var response = $http
											.get('https://maps.googleapis.com/maps/api/geocode/json?address='
													+ addr);

									response
											.success(function(data) {

												console
														.log("[main] # of matching addresses: "
																+ data.results.length)

												$scope.locations = data.results;

												$scope.page = 'locations';
											})

									response
											.error(function(data, status,
													headers, config) {
												alert("AJAX failed to get data, status="
														+ status);
											})
								};

								$scope.saveBusinessOrg = function(id) {
									$scope.jsonObj = angular.toJson($scope.org,
											false);
									console.log("[update] data: "
											+ $scope.jsonObj);

									if ($scope.operation == "update") {
										var response = $http.put(
												'/involveMINT/rest/org/business/'
														+ id, $scope.jsonObj);
										response
												.success(function(data, status,
														headers, config) {
													$scope.statusTitle = 'Update Status'
													$scope.statusDescription = 'Successful update of Business ['
															+ $scope.org.orgName
															+ '] '
													$('#statusModal').modal({
														keyboard : true
													})
												});

										response
												.error(function(data, status,
														headers, config) {
													alert("AJAX failed to get data, status="
															+ status);
												})
									} else if ($scope.operation == "create") {
										var response = $http
												.post(
														'/involveMINT/rest/org/business/add',
														$scope.jsonObj);
										response
												.success(function(data, status,
														headers, config) {
													$scope.statusTitle = 'Add Status'
													$scope.statusDescription = 'Successful creation of Business ['
															+ $scope.org.orgName
															+ '] '
													$('#statusModal').modal({
														keyboard : true
													})
												});

										response
												.error(function(data, status,
														headers, config) {
													alert("AJAX failed to get data, status="
															+ status);
												})
									}
								};

								$scope.uploadFile = function() {
									var file = $scope.myFile;

									console.log('file is ');
									console.dir(file);

									var uploadUrl = "FileUploadServlet";
									fileUpload.uploadFileToUrl(file, uploadUrl, $scope);
								};

							} ]);

	// var engine = new Bloodhound({
	// identify: function(o) { return o.id_str; },
	// queryTokenizer: Bloodhound.tokenizers.whitespace,
	// datumTokenizer:
	// Bloodhound.tokenizers.obj.whitespace('name',
	// 'screen_name'),
	// dupDetector: function(a, b) { return a.id_str ===
	// b.id_str; },
	// prefetch: '/involveMINT/rest/admin/types/',
	// remote: {
	// url: '/involveMINT/rest/admin/types/%QUERY',
	// wildcard: '%QUERY'
	// }
	// });
	//						
	// function engineWithDefaults(q, sync, async) {
	// if (q === '') {
	// sync(engine.get('1'));
	// async([]);
	// }
	//
	// else {
	// engine.search(q, sync, async);
	// }
	// }
	//						
	// $('#rmtAddress').typeahead({
	// hint: $('.Typeahead-hint'),
	// menu: $('.Typeahead-menu'),
	// minLength: 0,
	// classNames: {
	// open: 'is-open',
	// empty: 'is-empty',
	// cursor: 'is-active',
	// suggestion: 'Typeahead-suggestion',
	// selectable: 'Typeahead-selectable'
	// }
	// }, {
	// source: engine,
	// displayKey: 'projTypeName'
	// })
	// .on('typeahead:asyncrequest', function() {
	// $('.Typeahead-spinner').show();
	// })
	// .on('typeahead:asynccancel typeahead:asyncreceive',
	// function() {
	// $('.Typeahead-spinner').hide();
	// });

	// $('#rmtAddress').typeahead(null, {
	// name : 'projTypePk',
	// display : 'projTypeName',
	// source : locations
	// });
})();