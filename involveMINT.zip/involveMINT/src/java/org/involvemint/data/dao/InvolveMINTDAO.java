package org.involvemint.data.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.involvemint.data.manager.ConnectionManager;
import org.involvemint.data.model.UserProfile;

public class InvolveMINTDAO {
	public static UserProfile getUserProfile(String emailId) {

		Connection conn = ConnectionManager.getConnection();

		PreparedStatement stmt1;
		try {
			stmt1 = conn.prepareStatement("select * from involvemint.user_profile up where up.email_id = ?");

			PreparedStatement stmt2 = conn
					.prepareStatement("select * from involvemint.user_profile up where up.email_id = ?");
			PreparedStatement stmt3 = conn
					.prepareStatement("select * from involvemint.user_profile up where up.email_id = ?");

			stmt1.setString(1, emailId);
			stmt2.setString(1, emailId);
			stmt3.setString(1, emailId);

			stmt1.executeQuery();
			stmt2.executeQuery();
			stmt3.executeQuery();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

}
