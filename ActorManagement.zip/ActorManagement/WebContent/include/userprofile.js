(function() {
  var app = angular.module("app", []);
  
  app.controller("HttpCtrl", function($scope, $http) {
    var app = this;
    $scope.navTitle = 'User Profile';
    $scope.operation="";
    $scope.isSaveDisabled = true;
    $scope.isDeleteDisabled = true;
     
    var response = $http.get('/ActorManagement/involvemint/users/');
    response.success(function(data) {
      $scope.users = data;
      console.log("[main] # of items: " + data.length)
      angular.forEach(data, function(element) {
        console.log("[main] user: " + element.firstName);
      });
    })
    response.error(function(data, status, headers, config) {
      alert("AJAX failed to get data, status=" + status);
    })
     
    $scope.getUser = function(id) {
      var response = $http.get('/ActorManagement/involvemint/users/'+ id );
       
      response.success(function(data) {
        $scope.user = data;
        $scope.operation="update";
        $scope.isSaveDisabled = false;
        $scope.isDeleteDisabled = false;
        })
       
      response.error(function(data, status, headers, config) {
        alert("AJAX failed to get data, status=" + status);
      })
    };
     
    $scope.searchUser = function(name) {
      var app = this;
      $scope.navTitle = 'Search Criteria';
       
      var response = $http.get('/ActorManagement/involvemint/users/search/' + name);
      response.success(function(data) {
        $scope.users = data;
        $scope.$apply();
 
        console.log("[searchActor] # of items: " + data.length)
        angular.forEach(data, function(element) {
          console.log("[searchActor] user: " + element.firstName);
        });
 
        });
       
      response.error(function(data, status, headers, config) {
        alert("AJAX failed to get data, status=" + status);
      })
    };
     
    $scope.clearForm = function() {
      $scope.user = {
    	  firstName:'',
          email:'',
          zipcode:'',
          city:'',
          remainingCredits:'',
          userProfileImage:'',
          totalCredits:''
      };
    }
     
    $scope.addNew = function(element) {
      $scope.operation="create";
      $scope.clearForm();
      main.id.focus();
      $scope.isSaveDisabled = false;
      $scope.isDeleteDisabled = true;
    }
     
    $scope.saveUser = function(id) {
      $scope.jsonObj = angular.toJson($scope.user, false);
      console.log("[update] data: " + $scope.jsonObj);
 
      if ($scope.operation == "update") {
        var response = $http.put('/ActorManagement/involvemint/users/' + id, $scope.jsonObj);
        response.success(function(data, status, headers, config) {
          $scope.resetSearch();
          });
         
        response.error(function(data, status, headers, config) {
          alert("AJAX failed to get data, status=" + status);
        })
      } else if ($scope.operation == "create") {
        var response = $http.post('/ActorManagement/involvemint/users/add', $scope.jsonObj);
        response.success(function(data, status, headers, config) {
          $scope.resetSearch();
          });
         
        response.error(function(data, status, headers, config) {
          alert("AJAX failed to get data, status=" + status);
        })  
      }
    };
     
    /*$scope.deleteActor = function(id) {
    	
      var response = $http.delete('/ActorManagement/rest/actors/' + id);
      response.success(function(data, status, headers, config) {
        $scope.resetSearch();
      });
         
      response.error(function(data, status, headers, config) {
        alert("AJAX failed to get data, status=" + status);
      })
    };*/
     
    $scope.resetSearch = function(firstName) {
      var app = this;
      $scope.operation="";
      $scope.clearForm();
      $scope.isSaveDisabled = true;
      $scope.isDeleteDisabled = true;
      $scope.navTitle = 'All Users';
      $scope.searchName = '';
       
      var response = $http.get('/ActorManagement/involvemint/users/');
      response.success(function(data) {
        $scope.users = data;
        $scope.$apply();
        console.log("[resetSearch] # of items: " + data.length)
        });
       
      response.error(function(data, status, headers, config) {
        alert("AJAX failed to get data, status=" + status);
      })
    };
    
  }); 
})();