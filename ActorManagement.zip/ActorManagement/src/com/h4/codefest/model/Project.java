package com.h4.codefest.model;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "project")
public class Project {
	private String projectId;
	private String name;
	private String desc;
	private String zipcode;
	private String address1;
	private String address2;
	private String city;
	private String state;
	@XmlElement
	public String getProjectId() {
		return projectId;
	}
	public void setProjectId(String projectId) {
		this.projectId = projectId;
	}
	@XmlElement
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@XmlElement
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
	@XmlElement
	public String getZipcode() {
		return zipcode;
	}
	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}
	@XmlElement
	public String getAddress1() {
		return address1;
	}
	public void setAddress1(String address1) {
		this.address1 = address1;
	}
	@XmlElement
	public String getAddress2() {
		return address2;
	}
	public void setAddress2(String address2) {
		this.address2 = address2;
	}
	@XmlElement
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	@XmlElement
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public Project(){
		
	}
	public Project(String projectId, String name, String desc, String zipcode, String address1, String address2,
			String city, String state) {
		super();
		this.projectId = projectId;
		this.name = name;
		this.desc = desc;
		this.zipcode = zipcode;
		this.address1 = address1;
		this.address2 = address2;
		this.city = city;
		this.state = state;
	}
	
	@Override
	public String toString() {
		return "Project [projectId=" + projectId + ", name=" + name + ", desc=" + desc + ", zipcode=" + zipcode
				+ ", address1=" + address1 + ", address2=" + address2 + ", city=" + city + ", state=" + state + "]";
	}
	
	
	
}
