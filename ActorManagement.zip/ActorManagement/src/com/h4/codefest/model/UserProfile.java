package com.h4.codefest.model;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "userprofile")
public class UserProfile {
	private String firstName;
	private String lastName;
	private String zipcode;
	private String address1;
	private String address2;
	private String city;
	private String state;
	private String email;
	private String password;
	private String dob;
	private int remainingCredits;
	private int totalCredits;
	private int totalHours;
	private int nPastProjects;
	
	private String userProfileImage;
	
	private List<Project> pastProjects = new ArrayList<Project>();
	private List<Project> currentProjects = new ArrayList<Project>();
	@XmlElement
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	@XmlElement
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	@XmlElement
	public String getZipcode() {
		return zipcode;
	}
	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}
	@XmlElement
	public String getAddress1() {
		return address1;
	}
	public void setAddress1(String address1) {
		this.address1 = address1;
	}
	@XmlElement
	public String getAddress2() {
		return address2;
	}
	public void setAddress2(String address2) {
		this.address2 = address2;
	}
	@XmlElement
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	@XmlElement
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	@XmlElement
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	@XmlElement
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	@XmlElement
	public int getRemainingCredits() {
		return remainingCredits;
	}
	public void setRemainingCredits(int remainingCredits) {
		this.remainingCredits = remainingCredits;
	}
	@XmlElement
	public int getTotalCredits() {
		return totalCredits;
	}
	public void setTotalCredits(int totalCredits) {
		this.totalCredits = totalCredits;
	}
	@XmlElement
	public int getTotalHours() {
		return totalHours;
	}
	public void setTotalHours(int totalHours) {
		this.totalHours = totalHours;
	}
	@XmlElement
	public int getnPastProjects() {
		return nPastProjects;
	}
	public void setnPastProjects(int nPastProjects) {
		this.nPastProjects = nPastProjects;
	}
	@XmlElement
	public List<Project> getPastProjects() {
		return pastProjects;
	}
	public void setPastProjects(List<Project> pastProjects) {
		this.pastProjects = pastProjects;
	}
	@XmlElement
	public List<Project> getCurrentProjects() {
		return currentProjects;
	}
	public void setCurrentProjects(List<Project> currentProjects) {
		this.currentProjects = currentProjects;
	}
	
	
	@XmlElement
	public String getUserProfileImage() {
		return userProfileImage;
	}
	public void setUserProfileImage(String userProfileImage) {
		this.userProfileImage = userProfileImage;
	}
	public UserProfile(){
		
	}
	public UserProfile(String firstName, String lastName, String zipcode, String address1, String address2, String city,
			String state, String emial, int remainingCredits, int totalCredits, int totalHours,
			int nPastProjects, String userProfileImage) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.zipcode = zipcode;
		this.address1 = address1;
		this.address2 = address2;
		this.city = city;
		this.state = state;
		this.email = emial;		
		this.remainingCredits = remainingCredits;
		this.totalCredits = totalCredits;
		this.totalHours = totalHours;
		this.nPastProjects = nPastProjects;
		this.userProfileImage = userProfileImage;
	}
	
	@Override
	public String toString() {
		return "UserProfile [firstName=" + firstName + ", lastName=" + lastName + ", zipcode=" + zipcode + ", address1="
				+ address1 + ", address2=" + address2 + ", city=" + city + ", state=" + state + ", email=" + email
				+ ", dob=" + dob + ", remainingCredits=" + remainingCredits + ", totalCredits=" + totalCredits
				+ ", totalHours=" + totalHours + ", nPastProjects=" + nPastProjects + ", userProfileImage="
				+ userProfileImage + "]";
	}
	
	
	
	
}
