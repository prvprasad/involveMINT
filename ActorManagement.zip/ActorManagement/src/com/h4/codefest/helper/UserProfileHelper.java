package com.h4.codefest.helper;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.apache.log4j.Logger;

import com.h4.codefest.model.Project;
import com.h4.codefest.model.UserProfile;

@Path("/users")
public class UserProfileHelper {
	private static final String api_version = "1.1";
	  static Logger logger = Logger.getLogger(UserProfileHelper.class);
	  private static Map<String, UserProfile> userProfileMap = new HashMap<String, UserProfile>();
	  
	  static{		  
		  
		  UserProfile userProfile = new UserProfile("Jennifer", "Lawrence", "15220", "100 Chatham Park dr", "Apt 305", "Pittsburgh",
					"PA", "siva@gmail.com",  30, 50, 50,
					5, "http://www.siempre-lindas.cl/wp-content/uploads/2014/11/jennifer-lawrence-164522_w1000.jpg");
		  
		  userProfile.getCurrentProjects().add(new Project("100", "Thomas Merton Center", "Thomas Merton Center", "15220", "", "", 
				  "Pittsburgh", "PA"));
		  userProfile.getCurrentProjects().add(new Project("100", "FRIENDS OF THE@AVALON PUBLIC LIBRARY", " to raise money to support our favorite place--the Avalon Public Library", "15220", "", "", 
				  "Pittsburgh", "PA"));
				  		
		  userProfileMap.put("siva@gmail.com", userProfile);
		  
		  userProfile = new UserProfile("Mary", "Torre", "15234", "", "", "Pittsburgh",
					"PA", "mary@gmail.com",  80, 20, 100,
					3, "http://media1.popsugar-assets.com/files/2013/01/01/5/192/1922398/e0bd827287eb8c5f_145351598.xxxlarge_2.jpg");
		  
		  userProfile.getCurrentProjects().add(new Project("100", "Thomas Merton Center", "Thomas Merton Center", "15220", "", "", 
				  "Pittsburgh", "PA"));
		  userProfile.getCurrentProjects().add(new Project("100", "FRIENDS OF THE@AVALON PUBLIC LIBRARY", " to raise money to support our favorite place--the Avalon Public Library", "15220", "", "", 
				  "Pittsburgh", "PA"));
				  		
		  userProfileMap.put("mary@gmail.com", userProfile);
	  }
	  
	  @Path("/version")
	  @GET
	  @Produces(MediaType.TEXT_HTML)
	  public String returnVersion() {
	    return "<p>Version: " + api_version + "</p>";
	  }
	  
	  
	// This is the default @PATH
	  @GET
	  @Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	  public ArrayList<UserProfile> getAllUsers() {
	    System.out.println("Getting all users...");
	    ArrayList<UserProfile> usersList = new ArrayList<UserProfile>(userProfileMap.values());
	    return usersList;
	  }
	  
	  
	  @Path("{id}")
	  @GET
	  @Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	  public UserProfile getUserByEmail(@PathParam("id") String id) {
	    System.out.println("Getting user by ID: " + id);
	 
	    UserProfile user = userProfileMap.get(id);
	    if (user != null) {
	    	logger.info("Inside getUserByEmail, returned: " + user.toString());
	    } else {
	    	logger.info("Inside getUserByEmail, ID: " + id + ", NOT FOUND!");
	    }
	    return user;
	  }
	  
	  
	  @Path("{id}")
	  @PUT
	  @Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	  @Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	  public UserProfile updateUser(UserProfile user) {
		  userProfileMap.put(""+user.getEmail(), user);
	     
	    System.out.println("updateUser with ID: " + user.getEmail());
	    if (user != null) {
	    	logger.info("Inside updateUser, returned: " + user.toString());
	    } else {
	    	logger.info("Inside updateUser, ID: " + user.getEmail() + ", NOT FOUND!");
	    }
	    return user; 
	  }
	   
	  @Path("/search/{query}")
	  @GET
	  @Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	  public ArrayList<UserProfile> searchUserByName(@PathParam("query") String query) {
	      System.out.println("Searching actor by Name: " + query);
	     
	      ArrayList<UserProfile> userList = new ArrayList<UserProfile>();    
	    for (UserProfile c: userProfileMap.values()) {
	      if (c.getFirstName().toUpperCase().contains(query.toUpperCase()))
	    	  userList.add(c);
	    }
	    return userList;
	  }
	   
	  @Path("/add")
	  @POST
	  @Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	  @Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	  public UserProfile addUser(UserProfile user) {
	    System.out.println("Adding actor with ID: " + user.getEmail());
	     
	    if (user != null) {
	    	System.out.println("Inside addActor, returned: " + user.toString());
	    	userProfileMap.put(""+user.getEmail(), user);
	    	System.out.println("# of actors: " + userProfileMap.size());
	    	System.out.println("Actors are now: " + userProfileMap);
	    } else {
	    	System.out.println("Inside addUser, Unable to add actors...");
	    } 
	    return user;
	  }
	   
	  @Path("{id}")
	  @DELETE
	  @Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	  public UserProfile deleteUserById(@PathParam("id") String id) {
	    System.out.println("Deleting actor with ID: " + id);
	     
	    UserProfile user = userProfileMap.remove(id);
	    if (user != null) {
	    logger.info("Inside deleteActorById, returned: " + user.toString());
	    } else {
	    logger.info("Inside deleteActorById, ID: " + id + ", NOT FOUND!");
	    }
	    return user;
	  }
	  
	  
}
