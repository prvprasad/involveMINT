package com.h4.codefest.shop.redeem;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "category")
public class Category {
	
	String catagoryName;
	List<Products> products = new ArrayList<Products>();
	
	@XmlElement
	public String getCatagoryName() {
		return catagoryName;
	}
	public void setCatagoryName(String catagoryName) {
		this.catagoryName = catagoryName;
	}
	
	@XmlElement
	public List<Products> getProducts() {
		return products;
	}
	public void setProducts(List<Products> products) {
		this.products = products;
	}
	
	public Category(){
		
	}
	public Category(String catagoryName, Products product) {
		super();
		this.catagoryName = catagoryName;
		products.add(product);
	}
	
	public Category(String catagoryName) {
		super();
		this.catagoryName = catagoryName;		
	}
	
	public void setProduct(Products product) {		
		products.add(product);	
	}
	
	@Override
	public String toString() {
		return "Category [ catagoryName=" + catagoryName + "]";
	}
	
	
}
