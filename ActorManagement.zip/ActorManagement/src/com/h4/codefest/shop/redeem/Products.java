package com.h4.codefest.shop.redeem;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "product")
public class Products {
	String compeny;
	String productName;
	Double price;
	Long timeCredits;
	String imageName;
	public Products(){
		
	}
	public Products(String compeny, String productName, Double price, Long timeCredits, String imageName) {
		super();
		this.compeny = compeny;
		this.productName = productName;
		this.price = price;
		this.timeCredits = timeCredits;
		this.imageName = imageName;
	}
	@XmlElement
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	@XmlElement
	public Double getPrice() {
		return price;
	}
	public void setPrice(Double price) {
		this.price = price;
	}
	@XmlElement
	public Long getTimeCredits() {
		return timeCredits;
	}
	public void setTimeCredits(Long timeCredits) {
		this.timeCredits = timeCredits;
	}
	@XmlElement
	public String getCompeny() {
		return compeny;
	}
	public void setCompeny(String compeny) {
		this.compeny = compeny;
	}
	@XmlElement
	public String getImageName() {
		return imageName;
	}
	public void setImageName(String imageName) {
		this.imageName = imageName;
	}
	
	@Override
	public String toString() {
		 return "Product [ productName=" + productName + ", price="
			        + price + ", timeCredits=" + timeCredits + ", getImageName=" + imageName
			        + ", compeny=" + compeny + "]";
	}
	
	
}
