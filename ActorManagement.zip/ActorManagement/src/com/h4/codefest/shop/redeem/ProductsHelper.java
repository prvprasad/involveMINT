package com.h4.codefest.shop.redeem;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.apache.log4j.Logger;

@Path("/products")
public class ProductsHelper {
	static Logger logger = Logger.getLogger(ProductsHelper.class);
	private static final String api_version = "1.01A rev.18729";
	private static Map<String, Category> catagories = new HashMap<String, Category>();
	static String xmlString = null;
	
	static{
		Category category = new Category("Food"); 
		category.setProduct(new Products("Pizza Hut", "Pizza", 10.00d, 20l, "Pizza.png"));
		category.setProduct(new Products("Panera Bread", "Soup", 5.00d, 5l, "Pizza.png"));
		category.setProduct(new Products("Chipotle", "Burrito", 5.00d, 10l, "Pizza.png"));
		
		catagories.put("Food", category);
		
		category = new Category("Gift Card"); 
		category.setProduct(new Products("Pizza Hut", "Any Item - Any Time", 10.00d, 20l, "Pizza.png"));
		category.setProduct(new Products("Panera Bread", "Any Item", 5.00d, 5l, "Pizza.png"));
		category.setProduct(new Products("Chipotle", "Any Item", 5.00d, 10l, "Pizza.png"));
		
		catagories.put("Gift Card", category);
		
		
		
		
	}
	
	
	
	public static Map<String, Category> getCatagories() {
		return catagories;
	}

	public static void setCatagories(Map<String, Category> catagories) {
		ProductsHelper.catagories = catagories;
	}

	@Path("/version")
	  @GET
	  @Produces(MediaType.TEXT_HTML)
	  public String returnVersion() {
	    return "<p>Version: " + api_version + "</p>";
	  }
	
	// This is the default @PATH
	  @GET
	  @Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	public ArrayList<Category> getAllCategories(){
		System.out.println("Getting all categories");  
		ArrayList<Category> categoryList = new ArrayList<Category>(catagories.values());
		return categoryList;
		
	}
	  
	@Path("/search/{query}")
	@GET
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })  
	public List<Products> getProductsByCategory(@PathParam("query") String query){
		List<Products> productsList = ((Category)catagories.get(query)).getProducts();
		return productsList;
	}
	
}
